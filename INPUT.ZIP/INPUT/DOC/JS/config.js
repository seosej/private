/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2012 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

require.config({map:{}}),require.config({paths:{"acplugins/tracked-send":Ac.Plugins.rna_resource_url+"/static/js/plugins/tracked-send/js/plugins/tracked-send",viewer:Ac.Plugins.rna_resource_url+"/static/js/plugins/tracked-send/js/viewer",acplugins:Ac.Plugins.rna_resource_url+"/static/js/plugins",aictools:Ac.Plugins.rna_resource_url+"/static/js/aicuc",aictools:Ac.Plugins.rna_resource_url+"/static/js/plugins/aicuc/js",pdmplugins:Ac.Plugins.rna_resource_url+"/static/js/plugins",fss:Ac.Plugins.rna_resource_url+"/static/js/plugins/fss",digsig:Ac.Plugins.rna_resource_url+"/static/js/plugins/digsig"}});